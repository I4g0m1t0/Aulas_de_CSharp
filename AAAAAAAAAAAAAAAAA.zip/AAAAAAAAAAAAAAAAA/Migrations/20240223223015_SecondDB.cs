﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AAAAAAAAAAAAAAAAA.Migrations
{
    public partial class SecondDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
