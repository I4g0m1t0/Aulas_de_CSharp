﻿namespace AAAAAAAAAAAAAAAAA.Models
{
    public class UsuarioModel
    {
        public int Id { get; set; }
        public string? Nome { get; set; }

        public int? Email { get; set;}
    }
}
